#include <stdio.h>
#include <stdlib.h>

int *twoSum(int *nums, int n, int m)
{
    int max = nums[0], min = nums[0];
    for (int i = 1; i < n; i++)
    {
        if (nums[i] > max)
            max = nums[i];
        else if (nums[i] < min)
            min = nums[i];
    }
    int htsize = max - min + 1;
    int *ht = calloc(htsize, sizeof(int));
    int offset = min;

    for (int i = 0; i < n; i++)
    {
        ht[nums[i] - offset] = i + 1;
    }
    int *retarray = malloc(2 * sizeof(int));
    for (int i = 0; i < n; i++)
    {

        int leftidx = m - nums[i] - offset;
        if (leftidx >= 0 && leftidx < htsize && ht[leftidx] && ht[leftidx] != (i + 1))
        {
            retarray[1] = ht[leftidx] - 1;
            retarray[0] = i;
            free(ht);
            return retarray;
        }
    }
    return 0;
}
int main()
{
    int n, m;
    scanf("%d%d", &n, &m);
    int *nums = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &nums[i]);
    }
    int *ans = twoSum(nums, n, m);
    printf("%d %d\n", ans[0], ans[1]);

    return 0;
}
